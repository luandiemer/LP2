﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalculadora
{
    public partial class Form1 : Form
    {
        double num1, num2;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtbox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar==(char)13)
            {
                SendKeys.Send("{TAB}");
                e.Handled = true;
            }
        }
        

        private void txtbox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnsub_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtbox1.Text, out num1) &&
              double.TryParse(txtbox2.Text, out num2))
            {
                txtbox3.Text = (num1 - num2).ToString("N2");
            }
            else
            {
                MessageBox.Show("Digite apenas numeros validos", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtbox1.Focus();
            }
        }

        private void btnmult_Click(object sender, EventArgs e)
        {

            if (double.TryParse(txtbox1.Text, out num1) &&
              double.TryParse(txtbox2.Text, out num2))
            {
                txtbox3.Text = (num1 * num2).ToString("N2");
            }
            else
            {
                MessageBox.Show("Digite apenas numeros validos", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtbox1.Focus();
            }
        }

        private void btndiv_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtbox1.Text, out num1) &&
             double.TryParse(txtbox2.Text, out num2))
            {
                if (num2 <= 0)
                {
                    MessageBox.Show("O Numero 2 deve ser maior que 0", "Atenção!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txtbox1.Focus();
                }
                else
                {
                    txtbox3.Text = (num1 / num2).ToString("N2");
                }
            
            }
            else
            {
                MessageBox.Show("Digite apenas numeros validos", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtbox1.Focus();
            }
        }

        private void btnlimp_Click(object sender, EventArgs e)
        {
            txtbox1.Clear();
            txtbox2.Clear();
            txtbox3.Clear();

            txtbox1.Focus();
        }

        private void btnsair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Tem certeza que deseja sair?", "Atenção!", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation) == DialogResult.OK)

            {
                Close();
            }
            else
            {
                txtbox1.Focus();
            }
        }

        private void btnsom_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtbox1.Text, out num1) &&
              double.TryParse(txtbox2.Text, out num2)) 
            {
                txtbox3.Text = (num1 + num2).ToString("N2");
            }
            else
            {
                MessageBox.Show("Digite apenas numeros validos", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtbox1.Focus();
            }

        }
    }
}
