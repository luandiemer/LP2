﻿namespace Pclasses
{
    partial class FormPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnhorista = new System.Windows.Forms.Button();
            this.btnmensalista = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnhorista
            // 
            this.btnhorista.Location = new System.Drawing.Point(143, 129);
            this.btnhorista.Name = "btnhorista";
            this.btnhorista.Size = new System.Drawing.Size(93, 48);
            this.btnhorista.TabIndex = 0;
            this.btnhorista.Text = "Horista";
            this.btnhorista.UseVisualStyleBackColor = true;
            this.btnhorista.Click += new System.EventHandler(this.btnhorista_Click);
            // 
            // btnmensalista
            // 
            this.btnmensalista.Location = new System.Drawing.Point(31, 129);
            this.btnmensalista.Name = "btnmensalista";
            this.btnmensalista.Size = new System.Drawing.Size(82, 48);
            this.btnmensalista.TabIndex = 1;
            this.btnmensalista.Text = "Mensalista";
            this.btnmensalista.UseVisualStyleBackColor = true;
            this.btnmensalista.Click += new System.EventHandler(this.btnmensalista_Click);
            // 
            // FormPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.btnmensalista);
            this.Controls.Add(this.btnhorista);
            this.Name = "FormPrincipal";
            this.Text = "Form Principal";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnhorista;
        private System.Windows.Forms.Button btnmensalista;
    }
}

