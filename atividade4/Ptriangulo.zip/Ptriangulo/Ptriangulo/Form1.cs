namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btncalc_Click(object sender, EventArgs e)
        {
            double ladoa, ladob, ladoc;
            if (Double.TryParse(txtladoa.Text, out ladoa) && Double.TryParse(txtladob.Text, out ladob) && Double.TryParse(txtladoc.Text, out ladoc))
            {
                {
                    if ((ladob + ladoc) > ladoa && ladoa > Math.Abs(ladob - ladoc) && ladob < (ladoa + ladoc) && ladob > Math.Abs(ladoa - ladoc) && ladoc < (ladoa + ladob) && ladoc > Math.Abs(ladoa - ladob))
                        {
                        if (ladoa == ladob && ladob == ladoc)
                            MessageBox.Show("Este tri�ngulo � equil�tero");
                        else
                        {
                            if (ladoa == ladob || ladob == ladoc || ladoa == ladoc)
                                MessageBox.Show("Este tri�ngulo � is�sceles");
                            else
                                MessageBox.Show("Este tri�ngulo � escaleno");
                        }

                    }
                    else
                        MessageBox.Show("N�o foi poss�vel montar um tri�ngulo com essas medidas");
                       
                }
            }
            else
                MessageBox.Show("Valores Inv�lidos", "Aten��o", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }

        private void btnlimp_Click(object sender, EventArgs e)
        {
            txtladoa.Clear();
            txtladob.Clear();
            txtladoc.Clear();
            txtladoa.Focus();

        }

        private void txtladoa_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar==(char)13)
            {
                SendKeys.Send("{TAB}");
                e.Handled = true;
            }
        }

        private void btnsair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Tem certeza que deseja sair?", "Aten��o", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation) == DialogResult.OK)
                Close();
            else
                txtladoa.Focus();
        }
    }
}