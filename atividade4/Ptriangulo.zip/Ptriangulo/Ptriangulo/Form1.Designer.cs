﻿namespace Ptriangulo
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtladoa = new System.Windows.Forms.TextBox();
            this.txtladob = new System.Windows.Forms.TextBox();
            this.txtladoc = new System.Windows.Forms.TextBox();
            this.lbla = new System.Windows.Forms.Label();
            this.lblb = new System.Windows.Forms.Label();
            this.lblc = new System.Windows.Forms.Label();
            this.btnlimp = new System.Windows.Forms.Button();
            this.btncalc = new System.Windows.Forms.Button();
            this.btnsair = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtladoa
            // 
            this.txtladoa.Location = new System.Drawing.Point(88, 54);
            this.txtladoa.Name = "txtladoa";
            this.txtladoa.Size = new System.Drawing.Size(100, 23);
            this.txtladoa.TabIndex = 0;
            this.txtladoa.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtladoa_KeyPress);
            // 
            // txtladob
            // 
            this.txtladob.Location = new System.Drawing.Point(88, 88);
            this.txtladob.Name = "txtladob";
            this.txtladob.Size = new System.Drawing.Size(100, 23);
            this.txtladob.TabIndex = 1;
            // 
            // txtladoc
            // 
            this.txtladoc.Location = new System.Drawing.Point(88, 121);
            this.txtladoc.Name = "txtladoc";
            this.txtladoc.Size = new System.Drawing.Size(100, 23);
            this.txtladoc.TabIndex = 2;
            // 
            // lbla
            // 
            this.lbla.AutoSize = true;
            this.lbla.Location = new System.Drawing.Point(32, 57);
            this.lbla.Name = "lbla";
            this.lbla.Size = new System.Drawing.Size(44, 15);
            this.lbla.TabIndex = 3;
            this.lbla.Text = "Lado A";
            // 
            // lblb
            // 
            this.lblb.AutoSize = true;
            this.lblb.Location = new System.Drawing.Point(32, 91);
            this.lblb.Name = "lblb";
            this.lblb.Size = new System.Drawing.Size(43, 15);
            this.lblb.TabIndex = 4;
            this.lblb.Text = "Lado B";
            // 
            // lblc
            // 
            this.lblc.AutoSize = true;
            this.lblc.Location = new System.Drawing.Point(32, 124);
            this.lblc.Name = "lblc";
            this.lblc.Size = new System.Drawing.Size(44, 15);
            this.lblc.TabIndex = 5;
            this.lblc.Text = "Lado C";
            // 
            // btnlimp
            // 
            this.btnlimp.Location = new System.Drawing.Point(124, 170);
            this.btnlimp.Name = "btnlimp";
            this.btnlimp.Size = new System.Drawing.Size(75, 23);
            this.btnlimp.TabIndex = 6;
            this.btnlimp.Text = "Limpar";
            this.btnlimp.UseVisualStyleBackColor = true;
            this.btnlimp.Click += new System.EventHandler(this.btnlimp_Click);
            // 
            // btncalc
            // 
            this.btncalc.Location = new System.Drawing.Point(32, 170);
            this.btncalc.Name = "btncalc";
            this.btncalc.Size = new System.Drawing.Size(75, 23);
            this.btncalc.TabIndex = 7;
            this.btncalc.Text = "Calcular";
            this.btncalc.UseVisualStyleBackColor = true;
            this.btncalc.Click += new System.EventHandler(this.btncalc_Click);
            // 
            // btnsair
            // 
            this.btnsair.Location = new System.Drawing.Point(216, 170);
            this.btnsair.Name = "btnsair";
            this.btnsair.Size = new System.Drawing.Size(75, 23);
            this.btnsair.TabIndex = 8;
            this.btnsair.Text = "Sair";
            this.btnsair.UseVisualStyleBackColor = true;
            this.btnsair.Click += new System.EventHandler(this.btnsair_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(88, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(147, 15);
            this.label1.TabIndex = 9;
            this.label1.Text = "Classificação de triângulos";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(335, 231);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnsair);
            this.Controls.Add(this.btncalc);
            this.Controls.Add(this.btnlimp);
            this.Controls.Add(this.lblc);
            this.Controls.Add(this.lblb);
            this.Controls.Add(this.lbla);
            this.Controls.Add(this.txtladoc);
            this.Controls.Add(this.txtladob);
            this.Controls.Add(this.txtladoa);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox txtladoa;
        private TextBox txtladob;
        private TextBox txtladoc;
        private Label lbla;
        private Label lblb;
        private Label lblc;
        private Button btnlimp;
        private Button btncalc;
        private Button btnsair;
        private Label label1;
    }
}