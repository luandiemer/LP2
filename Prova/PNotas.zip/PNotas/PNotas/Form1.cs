﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PNotas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnVerif_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[6, 10];
            string gabarito;
            string[] resultados = { "E", "B", "D", "C", "C", "A", "E", "C", "B", "A" };

            for (int i = 0; i < 6; i++)
            {
                for (int c = 0; c < 10; c++)
                {
                    gabarito = Interaction.InputBox("Aluno " + (i + 1).ToString() + " Coloque sua resposta " + (c + 1).ToString(), "Entrada de Dados");
                    gabarito = gabarito.ToUpper();

                    if (gabarito == "A" || gabarito == "B" || gabarito == "C" || gabarito == "D" || gabarito == "E")
                    {
                        if (gabarito == resultados[c])
                        {
                            lbxAlter.Items.Add("O Aluno " + (i + 1) + " acertou a questão: " + (c + 1).ToString() + ", Era " + resultados[c] + " escolheu " + gabarito);
                        }
                        else
                            lbxAlter.Items.Add("O Aluno " + (i + 1) + " errou a questão: " + (c + 1).ToString() +  ", Era " + resultados[c] + " escolheu " + gabarito);
                    }
                    else
                    {
                        MessageBox.Show("Coloque o dado requisitado!");
                        c--;
                    }
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
