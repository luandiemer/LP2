﻿namespace PNotas
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnVerif = new System.Windows.Forms.Button();
            this.lbxAlter = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnVerif
            // 
            this.btnVerif.Location = new System.Drawing.Point(42, 140);
            this.btnVerif.Name = "btnVerif";
            this.btnVerif.Size = new System.Drawing.Size(259, 95);
            this.btnVerif.TabIndex = 0;
            this.btnVerif.Text = "Verificar";
            this.btnVerif.UseVisualStyleBackColor = true;
            this.btnVerif.Click += new System.EventHandler(this.btnVerif_Click);
            // 
            // lbxAlter
            // 
            this.lbxAlter.FormattingEnabled = true;
            this.lbxAlter.Location = new System.Drawing.Point(356, 63);
            this.lbxAlter.Name = "lbxAlter";
            this.lbxAlter.Size = new System.Drawing.Size(328, 329);
            this.lbxAlter.TabIndex = 1;
            this.lbxAlter.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(789, 424);
            this.Controls.Add(this.lbxAlter);
            this.Controls.Add(this.btnVerif);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnVerif;
        private System.Windows.Forms.ListBox lbxAlter;
    }
}

