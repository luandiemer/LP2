namespace Pimc
{
    public partial class Form1 : Form
    {
       

        private void btnsair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Tem certeza que deseja sair?", "Aten��o!", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation) == DialogResult.OK)
                Close();
            else
                txtalt.Focus();

        }
    

        private void btnlimpa_Click(object sender, EventArgs e)
        {
            txtalt.Clear();
            txtpeso.Clear();
            txtresult.Clear();
            txtalt.Focus();
        }

        private void txtalt_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtalt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                SendKeys.Send("{TAB}");
                e.Handled = true;
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void btncalc_Click(object sender, EventArgs e)
        {
            double Altura, Peso, imc;
            if (txtalt.Text.Contains("."))
                txtalt.Text = txtalt.Text.Replace(".", ",");
            if (txtpeso.Text.Contains("."))
                txtpeso.Text = txtpeso.Text.Replace(".", ",");

            if (Double.TryParse(txtalt.Text, out Altura) && Double.TryParse(txtpeso.Text, out Peso))
            {
                
                if ((Altura <= 0) || (Peso <= 0))
                {
                    MessageBox.Show("Valores devem ser maior que 0", "Aten��o!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txtalt.Focus();
                }
                else
                {
                    imc = Peso / Math.Pow(Altura, 2);
                    imc = Math.Round(imc, 1);
                    txtresult.Text = imc.ToString("N1");

                    if (imc < 18.5)
                        MessageBox.Show("Sua classifica��o de IMC �: Magreza (Obesidade grau 0)");
                    if (imc <= 24.9 && imc >= 18.5)
                        MessageBox.Show("Sua classifica��o de IMC �: Normal (Obesidade grau 0)");
                    if (imc <= 29.9 && imc >= 25)
                        MessageBox.Show("Sua classifica��o de IMC �: Sobrepeso (Obesidade grau 1)");
                    if (imc <= 39.9 && imc >= 30)
                        MessageBox.Show("Sua classifica��o de IMC �: Obesidade (Obesidade grau 2)");
                    if (imc >= 40)
                        MessageBox.Show("Sua classifica��o de IMC �: Obesidade Grave (Obesidade grau 3)");
                }

            }
        }
    }
}

