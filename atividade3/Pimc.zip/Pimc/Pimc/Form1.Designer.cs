﻿namespace Pimc
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblalt = new System.Windows.Forms.Label();
            this.lblpeso = new System.Windows.Forms.Label();
            this.lblresult = new System.Windows.Forms.Label();
            this.txtalt = new System.Windows.Forms.TextBox();
            this.txtpeso = new System.Windows.Forms.TextBox();
            this.txtresult = new System.Windows.Forms.TextBox();
            this.btncalc = new System.Windows.Forms.Button();
            this.btnlimpa = new System.Windows.Forms.Button();
            this.btnsair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblalt
            // 
            this.lblalt.AutoSize = true;
            this.lblalt.Location = new System.Drawing.Point(47, 51);
            this.lblalt.Name = "lblalt";
            this.lblalt.Size = new System.Drawing.Size(39, 15);
            this.lblalt.TabIndex = 0;
            this.lblalt.Text = "Altura";
            // 
            // lblpeso
            // 
            this.lblpeso.AutoSize = true;
            this.lblpeso.Location = new System.Drawing.Point(47, 79);
            this.lblpeso.Name = "lblpeso";
            this.lblpeso.Size = new System.Drawing.Size(32, 15);
            this.lblpeso.TabIndex = 1;
            this.lblpeso.Text = "Peso";
            // 
            // lblresult
            // 
            this.lblresult.AutoSize = true;
            this.lblresult.Location = new System.Drawing.Point(47, 113);
            this.lblresult.Name = "lblresult";
            this.lblresult.Size = new System.Drawing.Size(59, 15);
            this.lblresult.TabIndex = 2;
            this.lblresult.Text = "Resultado";
            // 
            // txtalt
            // 
            this.txtalt.Location = new System.Drawing.Point(112, 48);
            this.txtalt.Name = "txtalt";
            this.txtalt.Size = new System.Drawing.Size(100, 23);
            this.txtalt.TabIndex = 3;
            this.txtalt.TextChanged += new System.EventHandler(this.txtalt_TextChanged);
            this.txtalt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtalt_KeyPress);
            // 
            // txtpeso
            // 
            this.txtpeso.Location = new System.Drawing.Point(112, 76);
            this.txtpeso.Name = "txtpeso";
            this.txtpeso.Size = new System.Drawing.Size(100, 23);
            this.txtpeso.TabIndex = 4;
            // 
            // txtresult
            // 
            this.txtresult.Enabled = false;
            this.txtresult.Location = new System.Drawing.Point(112, 105);
            this.txtresult.Name = "txtresult";
            this.txtresult.Size = new System.Drawing.Size(100, 23);
            this.txtresult.TabIndex = 5;
            // 
            // btncalc
            // 
            this.btncalc.Location = new System.Drawing.Point(31, 161);
            this.btncalc.Name = "btncalc";
            this.btncalc.Size = new System.Drawing.Size(75, 23);
            this.btncalc.TabIndex = 6;
            this.btncalc.Text = "Calcular";
            this.btncalc.UseVisualStyleBackColor = true;
            this.btncalc.Click += new System.EventHandler(this.btncalc_Click);
            // 
            // btnlimpa
            // 
            this.btnlimpa.Location = new System.Drawing.Point(121, 161);
            this.btnlimpa.Name = "btnlimpa";
            this.btnlimpa.Size = new System.Drawing.Size(75, 23);
            this.btnlimpa.TabIndex = 7;
            this.btnlimpa.Text = "Limpar";
            this.btnlimpa.UseVisualStyleBackColor = true;
            this.btnlimpa.Click += new System.EventHandler(this.btnlimpa_Click);
            // 
            // btnsair
            // 
            this.btnsair.Location = new System.Drawing.Point(212, 161);
            this.btnsair.Name = "btnsair";
            this.btnsair.Size = new System.Drawing.Size(75, 23);
            this.btnsair.TabIndex = 8;
            this.btnsair.Text = "Sair";
            this.btnsair.UseVisualStyleBackColor = true;
            this.btnsair.Click += new System.EventHandler(this.btnsair_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(344, 244);
            this.Controls.Add(this.btnsair);
            this.Controls.Add(this.btnlimpa);
            this.Controls.Add(this.btncalc);
            this.Controls.Add(this.txtresult);
            this.Controls.Add(this.txtpeso);
            this.Controls.Add(this.txtalt);
            this.Controls.Add(this.lblresult);
            this.Controls.Add(this.lblpeso);
            this.Controls.Add(this.lblalt);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblalt;
        private Label lblpeso;
        private Label lblresult;
        private TextBox txtalt;
        private TextBox txtpeso;
        private TextBox txtresult;
        private Button btncalc;
        private Button btnlimpa;
        private Button btnsair;
    }
}